﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack
{
    // <summary>
    /// The "Controller" for this program (implemnting MVC architecture). The dealer handles dealing cards, and telling the players wheter they won or lost. 
    /// </summary>
    public class Dealer
    {
        
        
        private Deck playingDeck = new Deck();
        private Player house = new Player(2000);
        private Player guest = new Player(999999999);
        private Hand guestHand = new Hand();
        private Hand houseHand = new Hand();
        private List<Hand> splitHands;
        private bool guestStand;
        private bool houseStand;

        




        
        public Dealer(Player guest, Player house, Deck deck)
        {
            this.guest = guest;
            this.house = house;
            this.playingDeck = deck;
        }
        








        public void newRound()
        {
            houseHand.surrenderCards();
            guestHand.surrenderCards();

            guestHand.add(playingDeck.deal()); 
            guestHand.add(playingDeck.deal());

            houseHand.add(playingDeck.deal());
            houseHand.add(playingDeck.deal());
        }





        public void Hit()
        {
            if (guestStand = false)
            {
                guestHand.add(playingDeck.deal());
            }
            houseAI();
        }





        public void Double()
        {
            if(guestStand = false)
            {
                guest.setBet(2 * guest.getBet());
                guestHand.add(playingDeck.deal());
                Stand();
            }
            houseAI();
        }





        public void Split()
        {
            if(guestHand.getHand()[0] == guestHand.getHand()[1])
            {
                Hand hand1 = new Hand();
                Hand hand2 = new Hand();
            }
        }





        public void Stand()
        {
            guestStand = true;
            while()
            houseAI();
        }





        public void houseAI()
        {
            if (houseHand.BJscore() < 17)
            {
                houseHand.add(playingDeck.deal());
            }
            else
            {
                houseStand = true;
            }
        }






        public bool checkForBust()
        {
            if (guestHand.BJscore() > 21)
            {
                guestHand.surrenderCards();
                
                

            }
            if (houseHand.BJscore() > 21)
            {
                houseHand.surrenderCards();
                house.setGameState(false);
                newRound();
            }
        }







        public bool checkForBJ()
        {
            if (guestHand.BJscore() == 21)
            {
                guest.setGameState(true);
            }
            if (houseHand.BJscore() == 21)
            {
                house.setGameState(true);
            }
            if(houseHand.BJscore() == 21 && guestHand.BJscore() == 21)
            {
                newRound();
            }
        }

    }

}

        

       

