﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack
{
    //Class for constructing a player's hand of cards.
    public class Hand
    {
       
        private List<Card> hand;





        public Hand()
        {
            hand = new List<Card>();
        }

        public List<Card> getHand()
        {
            return this.hand;
        }




        
		public List<Card> surrenderCards()
        {
            List<Card> discardHand = new List<Card>();

            foreach (Card card in hand)
            {
                discardHand.Add(card);
            }
            hand.Clear();
            return discardHand;
        }






       
		public void add(Card card)
        {
            hand.Add(card);
        }







		public int BJscore()
        {
            int preAceScore = 0;
            int numberOfAces = 0;
            int withAceScore = 0;
            foreach (Card card in hand)
            {
                if (card.suitToValue() != 1)
                {
                    preAceScore += card.suitToValue();
                }
                else
                {
                    numberOfAces++;
                }
            }







            for (int j = 0; j <= numberOfAces; j++)
            {
                withAceScore = (preAceScore + ((numberOfAces - j) * 11) + j);
                if (withAceScore <= 21)
                {
                    return withAceScore;
                }
            }
            return withAceScore;
        }







		public override string ToString()
        {
            string handString = "";
            foreach (Card card in hand)
            {
                handString = handString + card.ToString() + "\n";
            }
            return handString;
        }






    }
}
