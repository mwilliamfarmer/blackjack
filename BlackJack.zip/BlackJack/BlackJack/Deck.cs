﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack
{
    //Class for holding a deck object
    public class Deck
    {
        private List<Card> playingDeck;
        private List<Card> discards;
        private Random random = new Random();

        public Deck()
        {
            playingDeck = new List<Card>();
            discards = new List<Card>();

            foreach(Suit suit in Enum.GetValues(typeof(Suit)))
            {
                foreach(Count count in Enum.GetValues(typeof(Count)))
                {
                    playingDeck.Add(new Card(count, suit));
                }
            }
            
        }






        public void acceptDiscards(List<Card> discardedCards)
        {
            foreach(Card card in discardedCards)
            {
                discards.Add(card);
            }
        }







        //Deals a random card to the player
        public Card deal()
        {
            if (playingDeck.Count > 0)
            {
                int index = random.Next(0, playingDeck.Count);
                Card randomCard = playingDeck[index];
                playingDeck.RemoveAt(index);
                return randomCard;

            }
            else
            {
                while (discards.Count > 0)
                {
                    //The last card in the discarded section
                    int index = discards.Count - 1;
                    Card discardedCard = discards[index];
                    playingDeck.Add(discardedCard);
                    discards.RemoveAt(index);
                }
                return deal();
            }
        }






    }
}
