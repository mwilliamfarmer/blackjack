﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack
{
    //Class for holding a Card object
    public class Card
    {
        
        public Count count;
        public Suit suit;







        public Card(Count count, Suit suit)
        {
            this.count = count;
            this.suit = suit;
        }





        
        public int suitToValue()
        {
            int i = (int)count + 1;
            if (i > 10) { i = 10; }
            return i;
        }







      
        public string ToString()
        {
            return count + " of " + suit;
        }






    }
}
