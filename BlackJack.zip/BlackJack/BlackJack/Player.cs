﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack
{
   
    public class Player
    {
        //The player's money
        private int money;
        //The player's bet
        private int bet;
        //True for win, false for lose
        private bool gameState;

        public Player(int money)
        {
            this.money = money;
        }





        public void setBet(int i)
        {
            this.bet = i;
        }





        public int getBet()
        {
            return bet;
        }





        public bool getGameState()
        {
            return this.gameState;
        }





        public void setGameState(bool state)
        {
            this.gameState = state;
        }
        
    }

}
