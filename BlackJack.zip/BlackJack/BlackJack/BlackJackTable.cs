﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlackJack
{
    public partial class BlackJackTable : Form
    {
        private Dealer dealer = new Dealer(new Player(), new Player(), new Deck());





    
        public BlackJackTable()
        {
            InitializeComponent();
        }





        private void hit_Click(object sender, EventArgs e)
        {
            dealer.Hit();
        }






        private void double_Click(object sender, EventArgs e)
        {
            dealer.Double();
        }





        private void stand_Click(object sender, EventArgs e)
        {
            dealer.Stand();
        }





        private void split_Click(object sender, EventArgs e)
        {
            dealer.Split();
        }





    }
}
